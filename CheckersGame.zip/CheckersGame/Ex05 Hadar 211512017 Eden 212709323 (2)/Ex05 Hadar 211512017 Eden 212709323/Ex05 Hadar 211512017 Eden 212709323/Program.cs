﻿using System;
using System.Windows.Forms;

namespace Ex05_Hadar_211512017_Eden_212709323
{
    public static class Program
    {
        public static void Main()
        {
            FormSettings settingsForm = new FormSettings();
            DialogResult result = settingsForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                FormGameBoard gameBoardForm = new FormGameBoard();
                gameBoardForm.ShowDialog();
            }
        }
    }
}



