﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex05_Hadar_211512017_Eden_212709323
{
    public enum eGameState
    {
        InProgress,
        Player1Wins,
        Player2Wins,
        Draw,
    }
}
