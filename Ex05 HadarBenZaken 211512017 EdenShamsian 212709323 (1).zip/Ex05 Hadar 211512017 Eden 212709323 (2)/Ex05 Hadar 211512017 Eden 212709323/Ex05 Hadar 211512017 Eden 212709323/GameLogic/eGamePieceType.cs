﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex05_Hadar_211512017_Eden_212709323
{
    public enum eGamePieceType
    {
        Empty = ' ',
        Player1 = 'O',
        Player2 = 'X',
        KingPlayer1 = 'U',
        KingPlayer2 = 'K',
    }
}
